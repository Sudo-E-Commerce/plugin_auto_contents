//Support to check extension installed
var installExtensionStatus = document.getElementById("install-extension-status");
if(installExtensionStatus) {
  installExtensionStatus.remove();
}

//const slicedArray = array.slice(0, n); lấy n phần tử đầu tiên của 1 array
function calculatorStatic(data) {
  var c1 = c2 = c3 = c4 = c5 = c6 = medium = 0;
  var max = 7;
  var min = 0;
  var lengthData = data.length;
  $.each(data, function( index, value ) {
    $.each(value['headings'], function( i, v ) {
      let tag_level = parseInt(v.tag);
      if(tag_level < max) {
        max = tag_level;
      }
      if(tag_level > min) {
        min = tag_level;
      }
      switch (tag_level) {
        case 1:
          c1++;
          break;
        case 2:
          c2++;
          break;
        case 3:
          c3++;
          break;
        case 4:
          c4++;
          break;
        case 5:
          c5++;
          break;
        case 6:
          c6++;
          break;
        default:
          break;
      }
    });
  });

  return {
    'h1':Math.round(c1/lengthData),
    'h2':Math.round(c2/lengthData),
    'h3':Math.round(c3/lengthData),
    'h4':Math.round(c4/lengthData),
    'h5':Math.round(c5/lengthData),
    'h6':Math.round(c6/lengthData),
    'medium':Math.round((c1+c2+c3+c4+c5+c6)/lengthData),
    'max':max,
    'min':min
  };
}

document.addEventListener('SACE_render', async function(e) {
  var data = e.detail;
  console.log(data);
  //render tops
  var html_top = '';
  $.each(data, function( index, value ) {
    var html_top_item_detail = '';
    var cc = calculatorStatic([value]);
    $.each(value['headings'], function( i, v ) {
      html_top_item_detail += `<div class="outline-top-item-detail-item item-${v.tag}"  data-tag="${v.tag}" data-text="${v.text}">
          <div class="outline-top-item-detail-item-action">
              <button class="btn-info plus" title="Thêm heading này vào outline">+</button>
              <button class="btn-default minus" title="Double click để xóa heading này">-</button>
          </div>
          <h4><span class="color-${v.tag}">H${v.tag}</span> ${v.text}</h4>
      </div>`;
    });
    var html_top_item = `<div class="outline-top-item" data-title="${value['title']}" data-link="${value['link']}">
        <div class="outline-top-item-action">
            <button class="btn-info plus" title="Double click để thêm toàn bộ heading vào outline">+</button>
            <button class="btn-default minus" title="Double click để xóa url này">-</button>
        </div>
        <h4 class="outline-top-item-title">${index+1}. ${value['title']} <a href="${value['link']}" target="_blank"><i class="fa fa-external-link"></i></a></h4>
        <p class="outline-top-item-link">${value['link']}</p>
        <div class="outline-top-item-static">
            <button data-heading="0">All: ${cc.medium}</button>
            <button data-heading="1">H1: <span class="color-1">${cc.h1}</span></button>
            <button data-heading="2">H2: <span class="color-2">${cc.h2}</span></button>
            <button data-heading="3">H3: <span class="color-3">${cc.h3}</span></button>
            <button data-heading="4">H4: <span class="color-4">${cc.h4}</span></button>
            <button data-heading="5">H5: <span class="color-5">${cc.h5}</span></button>
            <button data-heading="6">H6: <span class="color-6">${cc.h6}</span></button>
        </div>
        <div class="outline-top-item-detail">
            ${html_top_item_detail}
        </div>
    </div>`;
    html_top += html_top_item;
  });
  $('#outline-top-result').html(html_top);

  //render trung binh
  var static_10 = calculatorStatic(data);
  var static_3 = calculatorStatic(data.slice(0, 3));
  var html_static = `<div class="outline-static-list flex flex-wrap justify-between active" data-top="3">
    <div class="outline-static-item outline-static-item-h2">
        <h3 class="text-orange">H2</h3>
        <p>${static_3.h2}</p>
    </div>
    <div class="outline-static-item outline-static-item-h3">
        <h3 class="text-green">H3</h3>
        <p>${static_3.h3}</p>
    </div>
    <div class="outline-static-item outline-static-item-h4">
        <h3 class="text-pink">H4</h3>
        <p>${static_3.h4}</p>
    </div>
    <div class="outline-static-item outline-static-item-h5">
        <h3 class="text-blue">H5</h3>
        <p>${static_3.h5}</p>
    </div>
    <div class="outline-static-item outline-static-item-h6">
        <h3 class="text-violet">H6</h3>
        <p>${static_3.h6}</p>
    </div>
    <div class="outline-static-item outline-static-item-h1">
        <h3 class="text-slate">H1</h3>
        <p>${static_3.h1}</p>
    </div>
    <div class="outline-static-item outline-static-item-medium">
        <h3 class="text-rose">Trung bình</h3>
        <p>${static_3.medium}</p>
    </div>
    <div class="outline-static-item outline-static-item-max">
        <h3 class="text-slate">Lớn nhất</h3>
        <p>H${static_3.max}</p>
    </div>
    <div class="outline-static-item outline-static-item-min">
        <h3 class="text-slate">Bé Nhất</h3>
        <p>H${static_3.min}</p>
    </div>
  </div>
  <div class="outline-static-list flex flex-wrap justify-between" data-top="10">
    <div class="outline-static-item outline-static-item-h2">
        <h3 class="text-orange">H2</h3>
        <p>${static_10.h2}</p>
    </div>
    <div class="outline-static-item outline-static-item-h3">
        <h3 class="text-green">H3</h3>
        <p>${static_10.h3}</p>
    </div>
    <div class="outline-static-item outline-static-item-h4">
        <h3 class="text-pink">H4</h3>
        <p>${static_10.h4}</p>
    </div>
    <div class="outline-static-item outline-static-item-h5">
        <h3 class="text-blue">H5</h3>
        <p>${static_10.h5}</p>
    </div>
    <div class="outline-static-item outline-static-item-h6">
        <h3 class="text-violet">H6</h3>
        <p>${static_10.h6}</p>
    </div>
    <div class="outline-static-item outline-static-item-h1">
        <h3 class="text-slate">H1</h3>
        <p>${static_10.h1}</p>
    </div>
    <div class="outline-static-item outline-static-item-medium">
        <h3 class="text-rose">Trung bình</h3>
        <p>${static_10.medium}</p>
    </div>
    <div class="outline-static-item outline-static-item-max">
        <h3 class="text-slate">Lớn nhất</h3>
        <p>H${static_10.max}</p>
    </div>
    <div class="outline-static-item outline-static-item-min">
        <h3 class="text-slate">Bé Nhất</h3>
        <p>H${static_10.min}</p>
    </div>
  </div>`;
  $('#outline-static .outline-static-list').remove();
  $('#outline-static').append(html_static);
});

// Create a button element
const button = document.createElement("button");
button.textContent = "Click để lấy tops google";
button.className = "btn-primary";

// Add a click event listener to the button
button.addEventListener("click", async (e) => {
  button.remove();
  $('#outline-top-result').html('<img src="/assets/img/chanhtuoi_loading_ajax.gif" width="32" height="32" /> Đang lấy dữ liệu ...');
  console.log("Click để lấy tops google clicked!");
  var keyword = await getKeyword();
  if(keyword){
    var hashKey = md5(keyword);
    await chrome.runtime.sendMessage({type: 'getTop',data: {'key':keyword, 'hashKey':hashKey}}, async (response) => {
      if(response) {
        var tops = [];
        var doc = await $.parseHTML(response);
        var results = await $(doc).find('.g');

        await results.each(async (i, result) => {
          let title = await $(result).find('h3').text();
          let link = await $(result).find('a').attr('href');
          await chrome.runtime.sendMessage({type: 'getHeading',data: {'url':link}}, async (response) => {
            var doc = await $.parseHTML(response);
            var headings = [];
            await $(doc).find(':header').each(async (i, header) => {
              var tag = await header.tagName.slice(1);
              var text = await $(header).text();
              if(text != '') {
                await headings.push({'tag':tag,'text':text});
              }
            });
            await tops.push({'title':title,'link':link,'headings':headings});
          });
        });
        await console.log('Received getTop', tops);
        //render dữ liệu tops
        var count = 0;
        while(count < 10) {
          if(tops.length >=10) {
            count = 10;
            tops = tops.slice(0, 10);//lấy 10 phần tử đầu cho top 10
            document.dispatchEvent(new CustomEvent('SACE_render', {detail: tops}));
          }else {
            await wait(1000);
            count++;
          }
          console.log(count);
        }
      }else {
        console.log('Error received getTop', response);
      }
    });
  }else {
    console.log('Không thấy keyword');
  }
});
var outlineTopPanelHeading = document.getElementById("outline-top-panel-heading");
if(outlineTopPanelHeading) {
  outlineTopPanelHeading.appendChild(button);
}