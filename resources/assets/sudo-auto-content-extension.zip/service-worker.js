// Listen for messages from the content script
chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (message.type == 'getTop') {
    const url = `https://www.google.com/search?q=${encodeURIComponent(message.data.key)}&num=15`;//lấy 15 để đảm bảo bỏ được top quảng cáo
    console.log('Link getTop: ', url);
    fetch(url)
      .then(response => response.text())
      .then(data => {
        sendResponse(data);
      })
      .catch(error => {
        console.error(error);
        sendResponse(false);
      });
    return true;
  }

  if (message.type == 'getHeading') {
    fetch(message.data.url)
      .then(response => response.text())
      .then(data => {
        sendResponse(data);
      })
      .catch(error => console.error(error));
    return true;
  }
});
